# capability-aware-slm-rag

本项目是一个针对 Small-Model RAG 的 diagnostic and adaptive enhancement layer。当前 repository 中的 Reference RAG 用于开发和实验验证，不代表项目创新点本身。

## Reference RAG

- Primary SLM: Qwen2.5-7B-Instruct
- Retriever embedding: BAAI/bge-base-en-v1.5
- Vector search: FAISS
- Top-k: 5
- Quantization: 4-bit NF4
- Generation: deterministic (`do_sample=false`)

## Data

- Natural Questions validation: 7830
- NQ controlled subset: 3216
- NQ retrieval corpus: 99,922 passages
- FEVER train: 145,449
- FEVER dev: 19,998
- processed FEVER dev: 6666 SUPPORTS + 6666 REFUTES
- FEVER valid gold-evidence samples: 13,229 / 13,332
- FEVER retrieval corpus: 5,396,106 passages

## Status

- data preparation completed
- retrieval pilot completed
- Reference RAG engineering validation completed
- primary SLM changed from 3B to 7B
- NQ and FEVER 7B C0/C1/C3 runs are complete across the experiment branches; frozen results and judge re-analysis are documented in [project status and direction](docs/PROJECT_STATUS_AND_DIRECTION.md).
- Diagnosis v2-expanded, Probe, Safe Binary and Controller are frozen on `feature/diagnosis-probe-zheng` at `7c7863f`; project-sample annotations are published there. This E branch consumes the shared decision contract.
- `reranking` at `338ff34` implements evidence refinement with offline retrieval evaluation; generator-level gains have not been measured there.
- E implements Verification / Answer Repair with a Controller adapter, resumable experiments, provenance checks, paired evaluation and deferred human review. v4 and v5 real T4 runs are archived; v5 adds no frozen-metric gain. v6r1 adds extractive NQ and an optional independent FEVER MNLI experiment, with 81 passing CPU checks; its new GPU run is pending because the Colab browser window became unavailable. See [current handoff](docs/ANSWER_REPAIR_HANDOFF.md), [latest results](docs/ANSWER_REPAIR_RESULTS_20261014.md), and [Colab / Kaggle](docs/ANSWER_REPAIR_COLAB.md). Reliable repair gains remain unverified. Changes are local and uncommitted.
- The frozen preliminary protocol remains in [docs/PRELIMINARY_EXPERIMENT.md](docs/PRELIMINARY_EXPERIMENT.md).

## Engineering Validation

These are **engineering smoke tests** only. They do **not** answer the Preliminary Recoverability Experiment research questions.

**NQ 3B historical smoke test v2** (`results/base_rag/nq_smoke_test_v2.jsonl`): 20 samples; EM = 0.3000; Average F1 = 0.3460; gold evidence in Top-5 = 17/20; retrieval miss = 3/20; gold in Top-5 but wrong = 11/20.

**NQ 7B smoke test** (`results/base_rag/nq_smoke_test_7b.jsonl`): 20 samples; EM = 0.4000; Average F1 = 0.4770; gold evidence in Top-5 = 17/20; retrieval miss = 3/20; gold in Top-5 but wrong = 9/20.

**FEVER 3B smoke test** (`results/base_rag/fever_smoke_test.jsonl`): 20 samples; classification accuracy = 0.8000; gold evidence in Top-5 = 20/20; retrieval miss = 0; gold in Top-5 but prediction wrong = 4. This run used a reduced controlled candidate corpus, so 20/20 retrieval hit is **not** a formal retrieval result.

## Quick Start

See [docs/SETUP.md](docs/SETUP.md).
