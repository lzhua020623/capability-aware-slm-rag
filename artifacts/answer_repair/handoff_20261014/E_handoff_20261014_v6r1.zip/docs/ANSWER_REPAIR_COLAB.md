# E 的 Colab / Kaggle 实验

2026-10-14：v5 已跑完 112 条真实预测并归档，见 [结果报告](ANSWER_REPAIR_RESULTS_20261014.md)。最新待运行版本是 [v6r1 notebook](../notebooks/answer_repair_colab_v6r1_reviewed.ipynb)，配套 `artifacts/answer_repair/v6r1_reviewed/answer_repair_v6r1_reviewed_gpu.tar.gz`。运行协议见 [v6](ANSWER_REPAIR_V6.md)。v6r1 GPU 执行尚未确认：电脑控制返回 `cgWindowNotFound`；需要恢复 Colab 窗口后继续。

v6r1 归档 SHA-256：`74d40b01c96245e1caf2ac8af786bf3b05394971863bddc81a75a2a2afa45ef5`。Notebook 含 7 个代码单元格，依次完成校验、依赖与 81 项测试、28 条审核后开发样本、原 dev50 × 2 回归和结果导出。新旧包有各自独立输出目录。FEVER/NQ 策略各自只作用于对应数据集，分类器成本单独报告。不要重跑现有 smoke notebook 的所有历史单元格。

导出结果后，本地只用冻结包里的代码进行回放：

```sh
python3.11 scripts/audit_answer_repair_release.py --bundle-dir artifacts/answer_repair/v6r1_reviewed/gpu_bundle --results-dir artifacts/answer_repair/v6r1_reviewed/colab_20261014 --out-dir artifacts/answer_repair/v6r1_reviewed/release_audit
```

以下为 v4 历史执行记录。

v4 便携包为 `artifacts/answer_repair/v4/answer_repair_v4_gpu.tar.gz`，对应 [v4 notebook](../notebooks/answer_repair_colab_v4.ipynb)。真实实验在 [Colab T4](https://colab.research.google.com/drive/1XI0qoiW0NIQHiD7iOX8ewqM07Y-snxMQ) 执行；本地代码尚未提交或推送。

v4 包 SHA-256：`2a40d4fbaff591b02d116243f92404731cb71ccc5ce8a77092f4fda70dd3156e`。历史 v1/v2/v3 的包和输出分别保留；不同代码版本使用独立输出文件。

1. Colab 用“文件 → 上传笔记本”打开 v4 notebook，选择 T4 GPU。Kaggle 可导入 notebook，启用 GPU 和 Internet，将 v4 包添加为私有输入。
2. 执行 CUDA 检查，上传 v4 包。Notebook 会验证归档哈希及各个代码/输入文件的哈希。
3. 执行依赖安装、环境检查、54 项 CPU 测试及固定样本预检。首次真实调用会下载 Qwen2.5-7B-Instruct，后续复用云端 cache。
4. 在 FEVER/NQ 各 10 条上比较 `verify_repair` 与 `grounded_reanswer`，共 40 次额外生成，审核所有输出。
5. 可选开发格默认 `RUN_DEVELOPMENT=False`。审核后可运行选定 E 策略与 `reanswer` 对照，各数据集 50 条，共 200 次生成。候选策略在 `SELECTED_E_STRATEGY` 中显式选择。
6. 最后一格导出预测、汇总、环境、输入 manifest、文件校验和日志 ZIP。审核模板中的人工栏为空，生成模板不表示审核已经完成。

只做逐条 NF4 推理，无需重建检索库。Top-5 内容/顺序固定，每条 E 至多一次调用、384-token 上限。参考答案仅参与离线评分。NQ 引用字面匹配和 answer span 检查都不等于语义支持验证。

输出目录是 Colab 的 `/content/answer_repair_v4_outputs` 或 Kaggle 的 `/kaggle/working/answer_repair_v4_outputs`。不自动挂载 Drive。同一运行时内可续跑；运行时被释放后，需要重新上传包并恢复旧输出。释放前先导出结果。

## 已完成的工程 smoke

2026-10-13 的真实 T4 v4 各 10 条结果：

| 数据集 | C1 正确 | Verify 正确 / invalid | 独立候选正确 / invalid |
|---|---:|---:|---:|
| FEVER | 7/10 | 7/10，2 条 invalid | 8/10，0 条 invalid |
| NQ EM | 2/10 | 2/10，4 条 invalid | 2/10，4 条 invalid |

FEVER 的那一条标签改对引用了委内瑞拉 Valencia Municipality，不能证明目标实体及 administrative centre 的人口命题；不作为可靠的 grounded repair 成功。NQ 独立候选改了两条文本，但 EM 无增益，胫骨/腓骨样本仍回答了单个骨骼的相对位置。引用检查合法的 keep 也存在引用无关实体的情况。

v4 已修复完整 JSON 末 token 附带反引号的问题：保存原始输出及实际提交解析的对象文本，严格 schema 和 quote 检查保持不变。固定 50 条开发结果已经完成：FEVER 45→46，但新增正确是实体不匹配的 Valencia；NQ 20→20，改对 1 条、改错 1 条。Reanswer 两套均无增益。smoke 是该开发集的子集，不作为独立第二批数据合并统计。完整输出、成本、案例和包哈希见 [结果报告](ANSWER_REPAIR_RESULTS_20261013.md)。

## 重新生成 notebook

```bash
python3.11 scripts/build_answer_repair_notebook.py \
  --bundle artifacts/answer_repair/v4/answer_repair_v4_gpu.tar.gz \
  --out notebooks/answer_repair_colab_v4.ipynb \
  --strategy grounded_reanswer
```

生成器嵌入归档哈希，并对 8 个代码单元格做语法检查。已存在的归档拒绝被不同代码覆盖，下一版算法使用新的包名及目录；旧包内文档也是当时的代码快照。

## Controller 与 E 整合

E 对最终 `ControllerDecision` 的执行接口见 [ANSWER_REPAIR.md](ANSWER_REPAIR.md)。上游分支冻结于 `7c7863f98f87e892119481a79e23ca6dcebdced0`。隔离整合包 `artifacts/answer_repair/e_controller_gpu.tar.gz` 复用该分支的 Diagnosis、Probe、Safe Binary、Controller 与 v4 E；不重训或调阈值。

它只验证 Controller→E：另外两类增强动作仅记录，不执行。Probe 与 E 共用一份 NF4 模型，分别记录调用/token/生成延迟。固定开发样本来自训练交集，不能将该结果当作 held-out 或完整 adaptive system 效果。

实际整合已在 T4 跑完固定 100 条：27 次 Probe、1 次 E；FEVER / NQ 正确数均未改变。代码、原始输出与运行日志已导出并逐条重放校验。组合下载包为 [E_answer_repair_20261013_results.zip](../artifacts/answer_repair/session_20261013/E_answer_repair_20261013_results.zip)。
