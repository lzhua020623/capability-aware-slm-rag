# E 交接清单（2026-10-14）

E 负责 Evidence Utilisation 的 Verification / Answer Repair：接受 query、C1 Top-5 和初始答案，按 Controller 的最终 generation_repair 决策运行，返回最终答案、引用、处理状态及成本。Diagnosis/Probe/Controller 阈值仍由上游负责人维护。

当前状态：工程实现和本地自动验收已完成；v6r1 新版 GPU 实验受外部环境阻塞，不能把 E 算法验收标成完成。人工审核按用户指令暂缓，既不伪填，也不阻塞其他开发。所有修改仍在本地 `feature/verification-answer-repair`，未提交/推送。

| 内容 | 状态 | 入口或依据 |
|---|---|---|
| 统一修复接口、结构校验、证据来源与回退 | 已实现 | `src/compensation/answer_repair.py` |
| 原答案隐藏的候选、同模型二次核验 | 已实测并保留负结果 | `ANSWER_REPAIR_V5.md`，112 条真实输出 |
| NQ 只生成一次原文片段 | 已实现、待 GPU 效果验证 | `src/compensation/extractive_repair.py` |
| FEVER 独立 MNLI、分窗和冲突回退 | 已实现、待 GPU 效果验证 | `src/compensation/nli_repair.py` |
| 接受上游 ControllerDecision，其他 action 零调用 | 已验收兼容性 | `controller_adapter.py`，100 条历史真实决策回放 |
| 断点续跑、模型版本、两类成本、结果指纹 | 已检查 | `scripts/run_answer_repair.py` |
| 固定训练开发集及隔离 validation/test | 已冻结 | `configs/splits/answer_repair_reviewed_v6.json` |
| 单元与集成检查 | 81 项通过 | 当前代码与冻结包分别运行 |
| 真实 tokenizer 分窗完整性 | 64 输入通过 | 365 窗口，未执行模型推断 |
| v5 原始输出和冻结代码 CPU 回放 | 112 条通过 | `v5_reviewed/release_audit/cpu_replay.json` |
| v6r1 28 条 + 原 dev100 GPU 实验 | 外部阻塞 | Chrome 窗口不可访问 `cgWindowNotFound` |
| 新输出前后答案成对人工验收 | 用户要求暂缓 | v5 112 条待审核，v6r1 待真实输出 |
| 9 条初始边界样本 | 用户要求暂缓 | cohort manifest 的 deferred |
| 全框架 held-out 与三补偿操作比较 | 团队后续 | 不属于本次 E 单模块完成证明 |

## 运行和结果入口

最新 notebook：`notebooks/answer_repair_colab_v6r1_reviewed.ipynb`。
便携包：`artifacts/answer_repair/v6r1_reviewed/answer_repair_v6r1_reviewed_gpu.tar.gz`。
完整操作见 `ANSWER_REPAIR_COLAB.md`；运行前协议见 `ANSWER_REPAIR_V6.md`。

恢复 Colab T4 窗口后执行最新版的 7 个代码单元格，下载结果 ZIP。旧 v1–v5 notebook 和输出不要整本重跑或覆盖。128 条新预测对应两批开发材料，共 123 个唯一 dataset/sample_id；各批单独报告。

CPU 验收和生成待人工审核队列：

```sh
python3.11 scripts/audit_answer_repair_release.py --bundle-dir artifacts/answer_repair/v6r1_reviewed/gpu_bundle --results-dir artifacts/answer_repair/v6r1_reviewed/colab_20261014 --out-dir artifacts/answer_repair/v6r1_reviewed/release_audit
```

回放工具先验证冻结源文件与结果 manifest，再导入该归档里的验证器；不会用后续版本代码重解释历史结果。语义正确性始终单列，没有人工复评时保持 null/pending。

## 接口示例

```python
from src.compensation.controller_adapter import generation_repair
from src.compensation.qwen_repair import QwenRepairGenerator

# 上游负责构造 request 和已完成 Probe 的 decision；服务期间复用模型。
generator = QwenRepairGenerator()
result = generation_repair(request, decision, generator,
                           strategy="extractive_reanswer")  # NQ 实验
```

```python
from src.compensation.nli_repair import MNLIVerifier
verifier = MNLIVerifier()
result = generation_repair(request, decision, strategy="fever_nli",
                           verifier=verifier)  # FEVER 独立模型实验
```

两者均为显式选择的新实验选项，没有修改上游路由或静默晋升默认策略。`independent_support_status=nli_entailment/nli_contradiction` 表示独立模型的判断，仍不是人工真值。返回原答案也不意味着原答案已获证实。

## 当前可写入报告的结论

v5 同模型复核增加成本但没有提高冻结正确数；不能把六个 yes 当作语义支持证明。v4 在审核后的 FEVER 14 条上 4→6，NQ 的 2→4 则来自已确认正确对照的措辞变化，不能宣传为两个真实错误修复。v6r1 尚无 GPU 指标。是否保留哪一条策略，要看后续真实输出、误修及成本，不能只以单元测试通过来验收算法效果。
