# E 开发实验结果：2026-10-14

## v5 已完成：同模型复核没有改善结果

Colab T4，固定 28 条训练开发样本，四组共 112 条真实输出、123 次 Qwen 调用。GPU 包 SHA-256 `4f115e81d9698e60f3db6f29d2b018c0388f8daf6f3ca7ed4a3b74723485b9dd`；输出 ZIP `2a43425501468e666087fa26df4627ad648847ff673ff49156c8e3addc8e93d7`。全部输出已归档并通过 CPU 回放，原始候选在 query/guarded 两组一致。回放验证解析/决策/成本，不重新验证模型事实判断。

| 数据集 / 策略 | 冻结正确数（14 条） | 修复 / 误修 | 改答案 | 调用 | 生成秒数 |
|---|---:|---:|---:|---:|---:|
| FEVER / v4 grounded | 4 → 6 | 2 / 0 | 2 | 14 | 44.80 |
| FEVER / v5 query | 4 → 4 | 0 / 0 | 0 | 14 | 82.53 |
| FEVER / v5 guarded | 4 → 4 | 0 / 0 | 0 | 20 | 123.36 |
| FEVER / reanswer | 4 → 4 | 0 / 0 | 0 | 14 | 84.24 |
| NQ / v4 grounded | 2 → 4 | 2 / 0 | 4 | 14 | 73.18 |
| NQ / v5 query | 2 → 2 | 0 / 0 | 3 | 14 | 98.37 |
| NQ / v5 guarded | 2 → 2 | 0 / 0 | 3 | 19 | 117.74 |
| NQ / reanswer | 2 → 2 | 0 / 0 | 2 | 14 | 18.26 |

这些是原始 FEVER accuracy / NQ EM。NQ 人工确认正确对照为 5 条，但旧 EM 只认 2 条。v4 的两个 NQ EM 修复发生在已确认正确的 Columbia 和 bias 对照上，因此不能解释为真实错误修复。所有新输出的成对人工正确性/证据支持仍未验收，语义指标为 null。

FEVER 同模型复核接受了 6 条，其中 3 条仍与参考标签相反（Eva、Daggering、Bea）。六项全 yes 不提供独立支持，增加的六次调用没有修复错误。NQ query 组 8/14 输出无效，主要为答案不在连续引文中或引文标点被重写；有些答案的语义可能改善，但也有错误事件与部分答案，不能简单放宽全部校验。

原始文件：`artifacts/answer_repair/v5_reviewed/colab_20261014/`；校验报告 `artifacts/answer_repair/v5_reviewed/cpu_replay.json`。旧汇总字段 `*_observed_calls` 在两阶段实验中实际计数的是有 token 记录的样本数；`extra_calls` 和 token 总数正确。v6 起新增 observed_samples 并修正 observed_calls，不改写已冻结 v5 结果。

## v6 固定跟进实验

协议见 `ANSWER_REPAIR_V6.md`。最新版 v6r1 已实现并完成 81 项 CPU 测试、隔离归档内同样 81 项测试、四组完整预检及 48 个文件的哈希核对。使用真实固定 tokenizer 处理 FEVER 14+50 条输入，共生成 365 个窗口，每条最多 9 个窗口；所有非空白证据字符覆盖完整且输入不超过 512 tokens。该检查没有模型 forward，不能算 NLI 效果实验。

最新 E adapter 又回放了既有 100 条真实 ControllerDecision（使用冻结上游 schema 类）：71 no_action、26 retrieval_enhancement、2 evidence_refinement、1 generation_repair；历史 E 行为与单次调用完全保留。这是 CPU 兼容性回放，不是新 GPU 效果结果。

原 v6 包已上传，尝试添加启动单元格后浏览器窗口不可访问；无法确认代码粘贴和运行完成。后续固定 v6r1 修复了 JSON 环境元数据断点续跑，并纠正成本字段描述，策略/模型/阈值/样本不变。v6r1 尚未上传和执行。多次 `cua.getApp(com.google.Chrome)` 返回 `cgWindowNotFound`；本地无 CUDA。此处不提供虚构预测或效果指标。

待恢复 Colab 后运行已准备的 notebook，再归档、CPU 回放、报告四组结果并建立新输出审核队列。人工语义复评和 9 条初始边界样本由用户稍后处理。v5 的 112 条成对结果审核位于 `artifacts/answer_repair/v5_reviewed/release_audit/pending_semantic_pairs.jsonl`，每条绑定结果 SHA-256，人工字段均为空。

自动验收记录：`artifacts/answer_repair/v6r1_reviewed/validation.json`、`real_tokenizer_check.json`、`controller_contract_replay.json`。没有根据尚不存在的 v6r1 结果晋升默认策略。
