# E 交接清单（2026-10-14）

E 负责 Evidence Utilisation 的 Verification / Answer Repair：接受 query、C1 Top-5 和初始答案，按 Controller 的最终 generation_repair 决策运行，返回最终答案、引用、处理状态及成本。Diagnosis/Probe/Controller 阈值仍由上游负责人维护。

当前状态：工程实现、本轮计划的真实 GPU 实验、自动验收、归档和文档交接已完成。v6r1 的 128 条输出已通过冻结代码回放；可靠算法收益尚未验收，不能把整体研究验收标成完成。人工审核按用户指令暂缓，所有新输出的人工字段保持 pending/null。所有修改仍在本地 `feature/verification-answer-repair`，未提交/推送。

| 内容 | 状态 | 入口或依据 |
|---|---|---|
| 统一修复接口、结构校验、证据来源与回退 | 已实现 | `src/compensation/answer_repair.py` |
| 原答案隐藏的候选、同模型二次核验 | 已实测并保留负结果 | `ANSWER_REPAIR_V5.md`，112 条真实输出 |
| NQ 只生成一次原文片段 | 已实测，未晋升默认 | dev50 EM 20→7，长引文与无关片段需人工复评 |
| FEVER 独立 MNLI、分窗和冲突回退 | 已实测，未晋升默认 | 审核后 4→7，但 dev50 45→44，存在实体误判 |
| 接受上游 ControllerDecision，其他 action 零调用 | 已验收兼容性 | `controller_adapter.py`，100 条历史真实决策回放 |
| 断点续跑、模型版本、两类成本、结果指纹 | 已检查 | `scripts/run_answer_repair.py` |
| 固定训练开发集及隔离 validation/test | 已冻结 | `configs/splits/answer_repair_reviewed_v6.json` |
| 单元与集成检查 | 81 项通过 | 当前代码与冻结包分别运行 |
| 真实 tokenizer 分窗完整性 | 64 输入通过 | 365 窗口，未执行模型推断 |
| v5 原始输出和冻结代码 CPU 回放 | 112 条通过 | `v5_reviewed/release_audit/cpu_replay.json` |
| v6r1 28 条 + 原 dev100 GPU 实验 | 已完成、128 条回放通过 | 123 个唯一 ID；两批分别报告 |
| 新输出前后答案成对人工验收 | 用户要求暂缓 | v5 112 条、v6r1 128 条待审核；新版 42 条改动优先 |
| 9 条初始边界样本 | 用户要求暂缓 | cohort manifest 的 deferred |
| 全框架 held-out 与三补偿操作比较 | 团队后续 | 不属于本次 E 单模块完成证明 |

## 运行和结果入口

Colab notebook：`notebooks/answer_repair_colab_v6r1_reviewed.ipynb`。
Kaggle notebook：`notebooks/answer_repair_kaggle_v6r1_reviewed.ipynb`，适配平台自动解压，固定校验清单的哈希后逐文件校验 48 个文件。模型、算法、阈值与样本保持同一冻结版本。
便携包：`artifacts/answer_repair/v6r1_reviewed/answer_repair_v6r1_reviewed_gpu.tar.gz`。
完整操作见 `ANSWER_REPAIR_COLAB.md`；运行前协议见 `ANSWER_REPAIR_V6.md`。

Colab GPU 配额耗尽后，在 [Kaggle 私有草稿](https://www.kaggle.com/code/yearo111/e-answer-repair-v6r1-reviewed/edit) 完成实验，结果已下载且 GPU 会话已释放。原始 30 文件和四组指标位于 `artifacts/answer_repair/v6r1_reviewed/kaggle_20261014/`；结果 ZIP 为 `answer_repair_v6r1_reviewed_outputs_export.zip`，SHA-256 `3e9cd5eec2a658cf9ff5146c2b7322c9166d35367b9af34696439847589df684`。旧 v1–v5 输出保留。128 条新预测共 123 个唯一 dataset/sample_id，各批分别报告。

CPU 验收和生成待人工审核队列：

```sh
python3.11 scripts/audit_answer_repair_release.py --bundle-dir artifacts/answer_repair/v6r1_reviewed/gpu_bundle --results-dir artifacts/answer_repair/v6r1_reviewed/kaggle_20261014 --out-dir artifacts/answer_repair/v6r1_reviewed/release_audit
python3.11 scripts/prepare_answer_repair_triage.py --queue artifacts/answer_repair/v6r1_reviewed/release_audit/pending_semantic_pairs.jsonl --out-dir artifacts/answer_repair/v6r1_reviewed/release_audit
```

回放工具先验证冻结源文件与结果 manifest，再导入该归档里的验证器；不会用后续版本代码重解释历史结果。语义正确性始终单列，没有人工复评时保持 null/pending。

人工阅读入口：`release_audit/review_priority.md`；可编辑副本 `review_priority.jsonl`；审计底稿 `pending_semantic_pairs.jsonl` 保留。先审两条 FEVER 实体误判，再审 NQ 冻结指标退步；长引文可能仍语义正确，不能直接按 EM 代判。随后审核改善与其他改动，再审核保留答案的证据支持。每条分别判断初始/最终答案的正确性和支持性，记录审核人及理由。

## 接口示例

```python
from src.compensation.controller_adapter import generation_repair
from src.compensation.qwen_repair import QwenRepairGenerator

# 上游负责构造 request 和已完成 Probe 的 decision；服务期间复用模型。
generator = QwenRepairGenerator()
result = generation_repair(request, decision, generator,
                           strategy="extractive_reanswer")  # NQ 实验
```

```python
from src.compensation.nli_repair import MNLIVerifier
verifier = MNLIVerifier()
result = generation_repair(request, decision, strategy="fever_nli",
                           verifier=verifier)  # FEVER 独立模型实验
```

两者均为显式选择的新实验选项，没有修改上游路由或静默晋升默认策略。`independent_support_status=nli_entailment/nli_contradiction` 表示独立模型的判断，仍不是人工真值。返回原答案也不意味着原答案已获证实。

## 当前可写入报告的结论

v5 同模型复核增加成本但没有提高冻结正确数；不能把六个 yes 当作语义支持证明。v4 在审核后的 FEVER 14 条上 4→6，NQ 的 2→4 来自已确认正确对照的措辞变化。v6r1 FEVER 审核后 4→7，但 dev50 45→44；NQ 审核后 EM 2→0、dev50 20→7。引文来源合法和 NLI 高分都不足以保证支持结论。保留全部负结果，两种新策略均未晋升默认。完整成本及案例见最新结果报告。

工程与本轮开发实验已经可交接；人工复评完成后再决定下一版方案，团队的共同 held-out 与三个补偿操作整合另行验收。不会继续在这批开发材料上追调阈值来宣称 E 已有效。
