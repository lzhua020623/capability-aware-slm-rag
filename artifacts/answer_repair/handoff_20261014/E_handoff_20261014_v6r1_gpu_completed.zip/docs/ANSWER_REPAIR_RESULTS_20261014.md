# E 开发实验结果：2026-10-14

## v5 已完成：同模型复核没有改善结果

Colab T4，固定 28 条训练开发样本，四组共 112 条真实输出、123 次 Qwen 调用。GPU 包 SHA-256 `4f115e81d9698e60f3db6f29d2b018c0388f8daf6f3ca7ed4a3b74723485b9dd`；输出 ZIP `2a43425501468e666087fa26df4627ad648847ff673ff49156c8e3addc8e93d7`。全部输出已归档并通过 CPU 回放，原始候选在 query/guarded 两组一致。回放验证解析/决策/成本，不重新验证模型事实判断。

| 数据集 / 策略 | 冻结正确数（14 条） | 修复 / 误修 | 改答案 | 调用 | 生成秒数 |
|---|---:|---:|---:|---:|---:|
| FEVER / v4 grounded | 4 → 6 | 2 / 0 | 2 | 14 | 44.80 |
| FEVER / v5 query | 4 → 4 | 0 / 0 | 0 | 14 | 82.53 |
| FEVER / v5 guarded | 4 → 4 | 0 / 0 | 0 | 20 | 123.36 |
| FEVER / reanswer | 4 → 4 | 0 / 0 | 0 | 14 | 84.24 |
| NQ / v4 grounded | 2 → 4 | 2 / 0 | 4 | 14 | 73.18 |
| NQ / v5 query | 2 → 2 | 0 / 0 | 3 | 14 | 98.37 |
| NQ / v5 guarded | 2 → 2 | 0 / 0 | 3 | 19 | 117.74 |
| NQ / reanswer | 2 → 2 | 0 / 0 | 2 | 14 | 18.26 |

这些是原始 FEVER accuracy / NQ EM。NQ 人工确认正确对照为 5 条，但旧 EM 只认 2 条。v4 的两个 NQ EM 修复发生在已确认正确的 Columbia 和 bias 对照上，因此不能解释为真实错误修复。所有新输出的成对人工正确性/证据支持仍未验收，语义指标为 null。

FEVER 同模型复核接受了 6 条，其中 3 条仍与参考标签相反（Eva、Daggering、Bea）。六项全 yes 不提供独立支持，增加的六次调用没有修复错误。NQ query 组 8/14 输出无效，主要为答案不在连续引文中或引文标点被重写；有些答案的语义可能改善，但也有错误事件与部分答案，不能简单放宽全部校验。

原始文件：`artifacts/answer_repair/v5_reviewed/colab_20261014/`；校验报告 `artifacts/answer_repair/v5_reviewed/cpu_replay.json`。旧汇总字段 `*_observed_calls` 在两阶段实验中实际计数的是有 token 记录的样本数；`extra_calls` 和 token 总数正确。v6 起新增 observed_samples 并修正 observed_calls，不改写已冻结 v5 结果。

## v6r1 已完成：独立 NLI 有局部修复，原文抽取退步

协议见 `ANSWER_REPAIR_V6.md`。最新版 v6r1 已实现并完成 81 项 CPU 测试、隔离归档内同样 81 项测试、四组完整预检及 48 个文件的哈希核对。使用真实固定 tokenizer 处理 FEVER 14+50 条输入，共生成 365 个窗口，每条最多 9 个窗口；所有非空白证据字符覆盖完整且输入不超过 512 tokens。该检查没有模型 forward，不能算 NLI 效果实验。

最新 E adapter 又回放了既有 100 条真实 ControllerDecision（使用冻结上游 schema 类）：71 no_action、26 retrieval_enhancement、2 evidence_refinement、1 generation_repair；历史 E 行为与单次调用完全保留。这是 CPU 兼容性回放，不是新 GPU 效果结果。

Kaggle T4 x2 环境完成全部四组真实推断，共 128 条输出、123 个唯一 dataset/sample_id。审核后 cohort 与旧 dev50 重叠 FEVER 1 条、NQ 4 条，以下分别报告，不能合并为独立样本。GPU 会话已在下载和验证归档后释放。

| 数据集 / 开发批次 | 冻结正确数 | 指标修复 / 指标误修 | 改答案 | invalid / conflict / uncertain |
|---|---:|---:|---:|---:|
| FEVER / 审核后 14 条 | 4 → 7 | 3 / 0 | 3 | 0 / 4 / 3 |
| FEVER / 原 dev50 | 45 → 44 | 1 / 2 | 3 | 0 / 5 / 7 |
| NQ / 审核后 14 条 | 2 → 0 | 0 / 2 | 10 | 4 / 0 / 0 |
| NQ / 原 dev50 | 20 → 7 | 0 / 13 | 26 | 24 / 0 / 0 |

FEVER 使用 accuracy，NQ 使用冻结 EM。NQ 审核后 14 条的 F1 为 0.2920→0.3164，核心错误 9 条为 0.0202→0.2399；但正确对照 5 条的 F1 为 0.7813→0.4541。旧 dev50 的 F1 为 0.5489→0.3756。EM 的退步与语义误修须分开：不少原文抽取返回整句，包含正确答案也会 EM=0。

| 数据集 / 批次 | Qwen 调用 / 生成秒数 / 输入 tokens | NLI forward 批次 / 分类秒数 / 输入 tokens |
|---|---|---|
| FEVER / 审核后 14 条 | 0 / 0 / 无生成 | 29 / 12.75 / 21,910 |
| FEVER / 原 dev50 | 0 / 0 / 无生成 | 101 / 31.50 / 62,352 |
| NQ / 审核后 14 条 | 14 / 73.59 / 11,797 | 0 / 0 / 0 |
| NQ / 原 dev50 | 50 / 332.66 / 46,385 | 0 / 0 / 0 |

成本字段遵循运行前 v6 协议，模型下载/初始化不在上述逐条耗时中。两类模型预算不同，不能把 NLI 视为等预算的 Qwen 替代。v5 在 Colab、v6r1 在 Kaggle，依赖环境也不同，跨版本延迟不是受控速度比较。

### 具体结果说明

FEVER 审核后核心 10 条中，Daggering `156493`、Sugarland Express `203615`、Greek language `72578` 的标签改为参考标签；正确对照 4 条都没有改答案。Sugarland Express 同时出现在 dev50，不能重复算独立修复。候选引用分别直接涉及舞蹈、Spielberg 合写和阿尔巴尼亚的希腊语使用，但新输出的人工支持性仍待确认。

dev50 的两条 FEVER 指标误修暴露实体问题：`140820` 问 Men in Black II，NLI 却引用 2015 年比利时电影 Black，以 contradiction 0.9792 改成 REFUTES；`33982` 问 Henry Cavill 的 Superman 电影，引用 Henry's Crime，以 contradiction 0.9253 改成 REFUTES。高阈值和引文来源校验都没有阻止无关实体触发判定。因此不能依据审核后 14 条的改善晋升该策略。

NQ 的抽取机制成功保留原文字符，但答案与证据混为一个长片段。`5259818422556035007` 从 Ringo Starr 变成含该名字的整句；`970104939222709777` 从 Abbot Suger 变成艺术史整句，两者都由 EM=1 变成 0，尚不能据此称为语义改错。相反，Annie 演唱者、Loihi 定义和 Astros 对手等核心候选包含更多回答信息却仍 EM=0，需人工判断。

另有来源合法却没有回答问题的案例：`970985133701043298` 问 legislative act 的类别，抽取“国会两院多数通过”而没有类别；`-1209334507323554133` 问 crock pot 低档温度，抽取最低液位与加热位置说明，没有温度。这些是代理辅助分析，未写成人工真值。invalid 回退保留原答案，也不代表原答案正确或有证据支持。

### 归档、回放和人工队列

输入包 SHA-256：`74d40b01c96245e1caf2ac8af786bf3b05394971863bddc81a75a2a2afa45ef5`。
结果 ZIP SHA-256：`3e9cd5eec2a658cf9ff5146c2b7322c9166d35367b9af34696439847589df684`。
原始 30 文件位于 `artifacts/answer_repair/v6r1_reviewed/kaggle_20261014/`，包括预测、原始模型输出、NLI 全窗口概率、环境、安装/测试/运行日志及四组汇总。Python 3.13.15、torch 2.11.0+cu128、transformers 5.16.1、accelerate 1.14.0、bitsandbytes 0.50.2，模型 revision 均按冻结协议固定。

Kaggle 自动解压加载核对固定 checksum index 后验证全部 48 文件，保存 `input_integrity.json`；没有声称重新验证不存在的原归档字节。加载适配的原归档、预解压、篡改文件及篡改清单四种场景均已验收。云端 81 项测试通过。

`artifacts/answer_repair/v6r1_reviewed/release_audit/cpu_replay.json` 使用该运行自己的冻结代码验证全部 128 条：原始输出/完整 NLI trace 重放、输入与设置指纹、决策、引用、成本及汇总一致。CPU 回放不验证事实真值。

完整审核底稿为 `release_audit/pending_semantic_pairs.jsonl`；可编辑排序副本为 `release_audit/review_priority.jsonl`，阅读版为 `release_audit/review_priority.md`。128 条人工字段全部 pending/null，前 42 条为改动结果：17 条冻结指标退步、4 条改善、21 条其他改动；其中仍有跨 cohort 重复 ID，按两批保留。先审 FEVER 两条疑似实体误修，再审 NQ 指标退步，之后审改善与其他改动。对同一条初始/最终答案分别判断正确性与支持性，不能自动用参考匹配代填。v5 另外 112 条及初始 9 条边界样本继续暂缓。

本轮预先约定的工程、GPU、自动验收、归档与交接工作已完成。研究结论是目前策略尚未证明可靠净收益：保留负结果，不晋升默认策略，不继续追调同一小开发集阈值。待人工复评后，再决定是否开发“短答案与独立引文分离、实体相关性和不回答问题的回退”；新策略必须另冻结版本，并由团队安排共同未用于选策略的 held-out 评测。
