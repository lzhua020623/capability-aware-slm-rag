"""Evaluate E on archived C1 evidence; preflight is CPU-only and makes no calls.

Example: python3.11 scripts/run_answer_repair.py --dataset nq \
    --source-ref origin/feature/-ce-70B --all --check-only
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import subprocess
import sys
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.compensation.answer_repair import (
    DEFAULT_MAX_NEW_TOKENS, MODEL_NAME, RepairResult, build_reanswer_prompt,
    build_repair_prompt, repair_answer,
)
from src.diagnosis import DatasetName, DiagnosisInput, DiagnosisLabel, DiagnosisOutput, EvidenceItem
from src.evaluation.answer_repair import score_answer, summarize_repairs


def read_jsonl(raw: bytes, name: str) -> list[dict]:
    records = []
    for number, line in enumerate(raw.decode("utf-8-sig").splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON at {name}:{number}; original file preserved") from exc
        if not isinstance(record, dict):
            raise ValueError(f"Expected an object at {name}:{number}")
        records.append(record)
    return records


def runtime_input(record: dict, dataset: DatasetName | str) -> DiagnosisInput:
    """Explicit allowlist: no golds, metrics, C3, or judge fields reach E."""
    dataset = DatasetName(dataset)
    source_dataset = {"natural_questions": "nq", "nq": "nq", "fever": "fever"}.get(record.get("dataset"))
    if source_dataset != dataset.value or record.get("condition") != "C1":
        raise ValueError("Input must contain C1 records from the requested dataset only")
    if record.get("model_name") != MODEL_NAME:
        raise ValueError("C1 source must use the shared Qwen2.5-7B-Instruct model")
    evidence = record["evidence"]
    if not isinstance(evidence, list) or any(not isinstance(e, dict) for e in evidence):
        raise ValueError("C1 evidence must be a list of passage objects")
    return DiagnosisInput(
        sample_id=record["sample_id"], dataset=dataset,
        query=record["question_or_claim"], initial_answer=record["prediction"],
        evidence=[EvidenceItem(rank=i, passage_id=e["passage_id"], text=e["text"], score=e["score"])
                  for i, e in enumerate(evidence, 1)],
    )


def prepare_records(records: list[dict], dataset: DatasetName) -> list[tuple[dict, DiagnosisInput]]:
    prepared, seen = [], set()
    for record in records:
        request = runtime_input(record, dataset)
        if request.sample_id in seen:
            raise ValueError(f"Duplicate C1 sample ID: {request.sample_id}")
        seen.add(request.sample_id)
        # The original metric is recomputed offline before running the model.
        metrics = score_answer(request.initial_answer, record, dataset)
        if not isinstance(record.get("correct"), bool) or metrics["correct"] != record["correct"]:
            raise ValueError(f"Stored C1 correctness disagrees with the frozen scorer: {request.sample_id}")
        prepared.append((record, request))
    if not prepared:
        raise ValueError("No C1 records")
    return prepared


def read_diagnoses(path: Path, dataset: DatasetName) -> dict[str, DiagnosisOutput]:
    output = {}
    for row in read_jsonl(path.read_bytes(), str(path)):
        if row.get("dataset") != dataset.value:
            continue
        sample_id = str(row["sample_id"]).strip()
        if not sample_id or sample_id in output:
            raise ValueError(f"Empty or duplicate diagnosis ID: {sample_id!r}")
        output[sample_id] = DiagnosisOutput(
            diagnosis_label=row["diagnosis_label"], confidence=row["confidence"],
            needs_probe=row["needs_probe"],
        )
    return output


def route_status(diagnosis: DiagnosisOutput | None, all_samples: bool) -> str | None:
    """Minimal interface adapter. Confidence/Probe policy remains with Controller."""
    if all_samples:
        return None
    if diagnosis is None:
        raise ValueError("Missing diagnosis; use --all only for the explicit unrouted ablation")
    if diagnosis.needs_probe:
        return "skipped_pending_probe"
    if diagnosis.diagnosis_label != DiagnosisLabel.EVIDENCE_UTILISATION:
        return "skipped_other_diagnosis"
    return None


def run_fingerprint(source: bytes, diagnosis_source: bytes, settings: dict) -> str:
    h = hashlib.sha256()
    for part in (source, diagnosis_source, json.dumps(settings, sort_keys=True).encode()):
        h.update(len(part).to_bytes(8, "big"))
        h.update(part)
    for path in (
        "scripts/run_answer_repair.py", "src/compensation/answer_repair.py",
        "src/compensation/qwen_repair.py", "src/evaluation/answer_repair.py",
        "src/evaluation/qa.py", "src/evaluation/fever.py", "src/diagnosis/schema.py",
        "src/diagnosis/labels.py", "src/generation/qwen.py", "src/generation/__init__.py",
        "src/config.py", "configs/base.yaml",
    ):
        h.update(path.encode())
        h.update((ROOT / path).read_bytes())
    return h.hexdigest()


def result_record(
    source: dict, request: DiagnosisInput, result: RepairResult, fingerprint: str, settings: dict,
) -> dict:
    return {
        "sample_id": request.sample_id, "dataset": request.dataset.value, "condition": "E",
        "model_name": MODEL_NAME, "run_fingerprint": fingerprint, "settings": settings,
        "query": request.query,
        "retrieved_evidence_ids": [item.passage_id for item in request.evidence],
        **asdict(result), "changed": result.changed,
        "initial_metrics": score_answer(request.initial_answer, source, request.dataset),
        "final_metrics": score_answer(result.final_answer, source, request.dataset),
    }


def read_existing(path: Path, prepared: list[tuple[dict, DiagnosisInput]], fingerprint: str) -> list[dict]:
    if not path.exists():
        return []
    rows = read_jsonl(path.read_bytes(), str(path))
    if len(rows) > len(prepared):
        raise ValueError("Output contains more samples than this run")
    for row, (source, request) in zip(rows, prepared):
        if (row.get("run_fingerprint") != fingerprint or row.get("sample_id") != request.sample_id
                or row.get("dataset") != request.dataset.value or row.get("condition") != "E"
                or row.get("initial_answer") != request.initial_answer):
            raise ValueError("Output fingerprint/ID/order differs; use a separate output file")
        if (row.get("initial_metrics") != score_answer(request.initial_answer, source, request.dataset)
                or row.get("final_metrics") != score_answer(row["final_answer"], source, request.dataset)
                or row.get("changed") != (row["final_answer"] != request.initial_answer)):
            raise ValueError("Saved output metrics are inconsistent; original file preserved")
        if row.get("extra_calls") not in (0, 1) or not math.isfinite(row["latency"]) or row["latency"] < 0:
            raise ValueError("Invalid saved cost record")
    return rows


def append_record(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    # A complete final JSON line may lack a newline after interruption.
    with path.open("a+b") as handle:
        handle.seek(0, os.SEEK_END)
        if handle.tell():
            handle.seek(-1, os.SEEK_END)
            if handle.read(1) != b"\n":
                handle.write(b"\n")
        handle.write((json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n").encode())
        handle.flush()
        os.fsync(handle.fileno())


def validate_runtime_environment(saved: list[dict], current: dict | None) -> None:
    """Prevent resumed model calls from mixing revisions or GPU/package settings."""
    if any(row.get("runtime_environment") != current for row in saved if row["extra_calls"] == 1):
        raise ValueError("Runtime environment/model revision differs from saved calls; use a separate output file")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", choices=("nq", "fever"), required=True)
    source_args = parser.add_mutually_exclusive_group(required=True)
    source_args.add_argument("--c1", type=Path)
    source_args.add_argument("--source-ref", help="Read archived C1 directly from a local Git ref")
    route_args = parser.add_mutually_exclusive_group(required=True)
    route_args.add_argument("--all", action="store_true", help="Explicit development ablation; no diagnosis")
    route_args.add_argument("--diagnoses", type=Path, help="Runtime diagnosis JSONL, covering evaluated IDs")
    parser.add_argument("--strategy", choices=("verify_repair", "reanswer"), default="verify_repair")
    parser.add_argument("--max-new-tokens", type=int, default=DEFAULT_MAX_NEW_TOKENS)
    parser.add_argument("--limit", type=int, help="Evaluate a fixed prefix; use a separate output for each cohort")
    parser.add_argument("--out", type=Path)
    parser.add_argument("--check-only", action="store_true")
    parser.add_argument("--dry-run", action="store_true", help="Preflight plus first prompt; saves no predictions")
    args = parser.parse_args(argv)
    if args.max_new_tokens < 1 or (args.limit is not None and args.limit < 1):
        parser.error("Token budget and limit must be positive")
    dataset = DatasetName(args.dataset)
    if args.c1:
        raw, source_name = args.c1.read_bytes(), str(args.c1.resolve())
    else:
        # Separate argv elements prevent shell interpretation of ref names.
        ref = subprocess.check_output(["git", "rev-parse", "--verify", args.source_ref + "^{commit}"], cwd=ROOT, text=True).strip()
        source_name = f"{ref}:results/preliminary/{args.dataset}_c1_7b.jsonl"
        raw = subprocess.check_output(["git", "show", source_name], cwd=ROOT)
    prepared = prepare_records(read_jsonl(raw, source_name), dataset)
    if args.limit:
        prepared = prepared[:args.limit]
    diagnosis_source = args.diagnoses.read_bytes() if args.diagnoses else b""
    diagnoses = read_diagnoses(args.diagnoses, dataset) if args.diagnoses else {}
    statuses = {request.sample_id: route_status(diagnoses.get(request.sample_id), args.all)
                for _, request in prepared}
    settings = {
        "dataset": dataset.value, "strategy": args.strategy, "routing": "all" if args.all else "diagnosis",
        "max_new_tokens": args.max_new_tokens, "model_name": MODEL_NAME,
        "quantization": "nf4", "do_sample": False, "seed": 42,
        "sample_count": len(prepared),
        "sample_ids_sha256": hashlib.sha256(json.dumps([r.sample_id for _, r in prepared]).encode()).hexdigest(),
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "source": source_name,
    }
    fingerprint = run_fingerprint(raw, diagnosis_source, settings)
    out = args.out or ROOT / "results" / "answer_repair" / f"{args.dataset}_{args.strategy}_{settings['routing']}.jsonl"
    if args.c1 and out.resolve() == args.c1.resolve():
        raise ValueError("Output must not overwrite C1 input")
    if args.diagnoses and out.resolve() == args.diagnoses.resolve():
        raise ValueError("Output must not overwrite diagnosis input")
    if out.resolve().is_relative_to((ROOT / "results" / "preliminary").resolve()):
        raise ValueError("E output must be outside the frozen results/preliminary archive")
    saved = read_existing(out, prepared, fingerprint)
    plan = {
        "source": source_name, "dataset": dataset.value, "strategy": args.strategy,
        "routing": settings["routing"], "samples": len(prepared), "completed": len(saved),
        "routed_samples": sum(status is None for status in statuses.values()),
        "remaining_call_upper_bound": sum(statuses[r.sample_id] is None for _, r in prepared[len(saved):]),
        "fingerprint": fingerprint, "output": str(out),
    }
    print(json.dumps(plan, ensure_ascii=False, indent=2))
    if args.check_only or args.dry_run:
        if args.dry_run:
            build = build_repair_prompt if args.strategy == "verify_repair" else build_reanswer_prompt
            print(build(prepared[0][1]))
        return 0
    # Lock before rereading output or loading a model. One writer per file.
    out.parent.mkdir(parents=True, exist_ok=True)
    lock = out.with_suffix(out.suffix + ".lock")
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise ValueError(f"Output lock exists: {lock}. Confirm no writer is active before removing it.") from exc
    try:
        with os.fdopen(descriptor, "w") as handle:
            handle.write(str(os.getpid()))
        saved = read_existing(out, prepared, fingerprint)
        generator = None
        for source, request in prepared[len(saved):]:
            status = statuses[request.sample_id]
            if status is not None:
                result = RepairResult(request.initial_answer, request.initial_answer, status)
            else:
                if generator is None:
                    from src.compensation.qwen_repair import QwenRepairGenerator
                    generator = QwenRepairGenerator()
                    validate_runtime_environment(saved, getattr(generator, "runtime_environment", None))
                result = repair_answer(request, generator, strategy=args.strategy, max_new_tokens=args.max_new_tokens)
            row = result_record(source, request, result, fingerprint, settings)
            row["runtime_environment"] = getattr(generator, "runtime_environment", None) if result.extra_calls else None
            append_record(out, row)
            saved.append(row)
            print(f"[{len(saved)}/{len(prepared)}] {request.sample_id}: {result.status}", flush=True)
        summary = {"run_fingerprint": fingerprint, "routing": settings["routing"], "strategy": args.strategy,
                   **summarize_repairs(saved)}
        summary_path = out.with_suffix(".summary.json")
        temporary = summary_path.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(summary, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
        temporary.replace(summary_path)
        print(json.dumps(summary, indent=2, ensure_ascii=False))
    finally:
        lock.unlink()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError, subprocess.CalledProcessError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
