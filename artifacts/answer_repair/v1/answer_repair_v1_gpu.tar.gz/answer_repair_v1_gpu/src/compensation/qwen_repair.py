"""Lazy adapter to the existing frozen 7B NF4 generator. No hosted-model path."""

from __future__ import annotations

import importlib.metadata
import platform

from src.compensation.answer_repair import Generation, MODEL_NAME


class QwenRepairGenerator:
    def __init__(self) -> None:
        # Import only for a real run; preflight and tests need neither CUDA nor torch.
        import torch
        if not torch.cuda.is_available():
            raise RuntimeError("E requires CUDA for the frozen 7B NF4 experiment; run the environment checker first")
        from src.config import load_base_config, load_generator_config
        from src.generation.qwen import load_qwen_nf4

        config = load_generator_config()
        if config["model_name"] != MODEL_NAME or config.get("do_sample") is not False:
            raise RuntimeError("E requires the shared Qwen2.5-7B-Instruct greedy generator")
        seed = load_base_config()["seed"]
        if seed != 42:
            raise RuntimeError("E requires the shared seed 42")
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        self.tokenizer, self.model = load_qwen_nf4(MODEL_NAME)
        packages = {}
        for name in ("torch", "transformers", "accelerate", "bitsandbytes", "PyYAML"):
            try:
                packages[name] = importlib.metadata.version(name)
            except importlib.metadata.PackageNotFoundError:
                packages[name] = None
        self.runtime_environment = {
            "python": platform.python_version(), "packages": packages,
            "cuda_version": torch.version.cuda,
            "gpus": [{"name": torch.cuda.get_device_name(i),
                      "total_memory_bytes": torch.cuda.get_device_properties(i).total_memory}
                     for i in range(torch.cuda.device_count())],
            "model_revision": getattr(self.model.config, "_commit_hash", None),
            "tokenizer_revision": getattr(self.tokenizer, "init_kwargs", {}).get("_commit_hash"),
            "model_device_map": {str(k): str(v) for k, v in getattr(self.model, "hf_device_map", {}).items()},
        }

    def generate(self, prompt: str, max_new_tokens: int) -> Generation:
        from src.generation.qwen import apply_qwen_chat_template, generate_greedy

        chat = apply_qwen_chat_template(self.tokenizer, prompt)
        input_tokens = len(self.tokenizer.encode(chat))
        context_limit = getattr(self.model.config, "max_position_embeddings", None)
        if context_limit is not None and input_tokens + max_new_tokens > context_limit:
            raise RuntimeError("E prompt exceeds the model context window; refusing to silently truncate evidence")
        text, latency = generate_greedy(self.tokenizer, self.model, prompt, max_new_tokens)
        # Retokenized decoded text excludes EOS; keep its estimate label explicit.
        output_estimate = len(self.tokenizer.encode(text, add_special_tokens=False))
        return Generation(text, latency, input_tokens, output_estimate)
