# E v1 GPU experiment

This is a snapshot of local E code plus archived C1 evidence. No Git clone,
Wikipedia download or retrieval index is required. The bundle includes offline
reference answers for scoring; the runtime adapter excludes them from prompts.

Use Python 3.11+ and a CUDA-enabled PyTorch installation on an NVIDIA GPU host.
Install the remaining E dependencies:

```sh
python -m pip install -r requirements-answer-repair.txt
python scripts/check_answer_repair_environment.py --require-cuda --out environment.json
python -m unittest discover -s tests -v
```

First inspect and run the FEVER 10-sample engineering smoke:

```sh
python scripts/run_answer_repair.py --dataset fever --c1 inputs/fever_smoke10_c1.jsonl --all --check-only --out results/answer_repair/fever_smoke10.jsonl
python scripts/run_answer_repair.py --dataset fever --c1 inputs/fever_smoke10_c1.jsonl --all --out results/answer_repair/fever_smoke10.jsonl
```

Inspect every smoke output for JSON errors, fabricated or irrelevant quotes,
truncated JSON, changed answers and actual evidence support. This stage checks
execution, not algorithm effectiveness. No automatic semantic verifier is active.

After that review, run the fixed 50-sample development cohorts:

```sh
python scripts/run_answer_repair.py --dataset fever --c1 inputs/fever_dev50_c1.jsonl --all --out results/answer_repair/fever_dev50_verify.jsonl
python scripts/run_answer_repair.py --dataset nq --c1 inputs/nq_dev50_c1.jsonl --all --out results/answer_repair/nq_dev50_verify.jsonl
python scripts/run_answer_repair.py --dataset fever --c1 inputs/fever_dev50_c1.jsonl --all --strategy reanswer --out results/answer_repair/fever_dev50_reanswer.jsonl
python scripts/run_answer_repair.py --dataset nq --c1 inputs/nq_dev50_c1.jsonl --all --strategy reanswer --out results/answer_repair/nq_dev50_reanswer.jsonl
```

Both strategies use the same 384-token ceiling. The reanswer control receives
the original C1 instruction and evidence; it receives no initial answer.
Report fixed, regressed, net gain, invalid outputs, calls, tokens and latency.
Review all changed answers and quote/answer support, including kept answers.
NQ EM/F1 and FEVER accuracy remain the frozen offline metrics.

Samples come only from the intersection of the Diagnosis v1/v2 training sets,
with all validation/test IDs excluded. IDs are ranked by a seeded SHA-256 key
without consulting correctness or labels. Smoke IDs are the first development
IDs, so smoke and development results overlap and must not be pooled as
independent samples. These are exploratory development results, not held-out
final results. GPU verification has not yet been performed in this bundle.

Return environment.json, all result JSONL and .summary.json files, and manual
review notes. manifest.json records frozen IDs, source commits, checksums and
initial metric counts; bundle_checksums.json records every packaged file hash.
See docs/ANSWER_REPAIR.md for the full E protocol and resume rules.
