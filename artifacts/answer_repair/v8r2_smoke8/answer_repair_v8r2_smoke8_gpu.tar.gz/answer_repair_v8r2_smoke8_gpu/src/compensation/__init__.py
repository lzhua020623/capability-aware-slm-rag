"""Compensation / enhancement components."""
