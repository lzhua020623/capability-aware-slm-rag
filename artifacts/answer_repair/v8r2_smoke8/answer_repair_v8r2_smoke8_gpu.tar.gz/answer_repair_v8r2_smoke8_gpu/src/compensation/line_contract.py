"""Framing for one labeled response; never salvage a block from a saved response."""
from __future__ import annotations

import re

LINE_CONTRACT_VERSION = "single_labeled_response_v1"
CHECK_LABELS = ("ENTITY", "RELATION", "TYPE", "COVERAGE", "SUPPORT", "CONFLICT_FREE",
                "RANK", "QUOTE", "REASON")
CANDIDATE_LABELS = ("RANK", "QUOTE", "ANSWER")


def parse_labeled_lines(text: str, labels: tuple[str, ...]) -> dict[str, str]:
    lines = [line.strip() for line in text.strip().splitlines() if line.strip()]
    if len(lines) != len(labels):
        raise ValueError(f"Expected exactly {len(labels)} labeled lines")
    values = {}
    for line, label in zip(lines, labels):
        match = re.fullmatch(re.escape(label) + r":\s*(\S.*)", line)
        if match is None:
            raise ValueError(f"Expected {label} label and nonempty value")
        values[label] = match[1].strip()
    return values


def complete_labeled_output(text: str, labels: tuple[str, ...], *, insufficient: bool = False) -> bool:
    """Stop DURING generation after a newline closes the final nonempty value.

    Without a newline, the last field might still be a partial answer or reason.
    No text is cropped, and a saved repeated/conflicting response remains invalid.
    EOS can end a valid response without a newline; normal parsing then handles it.
    """
    if insufficient and text.strip() == "INSUFFICIENT":
        return True
    if not text.endswith(("\n", "\r")):
        return False
    try:
        parse_labeled_lines(text, labels)
    except ValueError:
        return False
    return True


def parse_evidence_rank(text: str) -> int:
    """A single integer, optionally surrounded by ONE matching bracket pair."""
    match = re.fullmatch(r"(?:([0-9]+)|\[\s*([0-9]+)\s*\])", text.strip())
    if match is None:
        raise ValueError("RANK must be one evidence block number")
    value = match[1] if match[1] is not None else match[2]
    if len(value) > 1 and value.startswith("0"):
        raise ValueError("RANK must not have leading zeros")
    return int(value)
