#!/bin/sh
set -eu
mkdir -p results
python -m unittest tests.test_answer_repair_v9 -v
python scripts/check_answer_repair_environment.py --require-cuda --out environment.json
python scripts/run_answer_repair_v9.py --dataset nq --strategy qwen_direct --all --c1 inputs/nq_smoke5_c1.jsonl --out results/nq_smoke5_qwen_direct.jsonl --check-only
python scripts/run_answer_repair_v9.py --dataset nq --strategy qwen_direct --all --c1 inputs/nq_smoke5_c1.jsonl --out results/nq_smoke5_qwen_direct.jsonl
python scripts/run_answer_repair_v9.py --dataset nq --strategy qwen_direct --all --c1 inputs/nq_smoke5_c1.jsonl --out results/nq_smoke5_qwen_direct.jsonl --replay
python scripts/run_answer_repair_v9.py --dataset nq --strategy evidence_id --all --c1 inputs/nq_smoke5_c1.jsonl --out results/nq_smoke5_evidence_id.jsonl --check-only
python scripts/run_answer_repair_v9.py --dataset nq --strategy evidence_id --all --c1 inputs/nq_smoke5_c1.jsonl --out results/nq_smoke5_evidence_id.jsonl
python scripts/run_answer_repair_v9.py --dataset nq --strategy evidence_id --all --c1 inputs/nq_smoke5_c1.jsonl --out results/nq_smoke5_evidence_id.jsonl --replay
python scripts/run_answer_repair_v9.py --dataset nq --strategy factored_evidence_id --all --c1 inputs/nq_smoke5_c1.jsonl --out results/nq_smoke5_factored_evidence_id.jsonl --check-only
python scripts/run_answer_repair_v9.py --dataset nq --strategy factored_evidence_id --all --c1 inputs/nq_smoke5_c1.jsonl --out results/nq_smoke5_factored_evidence_id.jsonl
python scripts/run_answer_repair_v9.py --dataset nq --strategy factored_evidence_id --all --c1 inputs/nq_smoke5_c1.jsonl --out results/nq_smoke5_factored_evidence_id.jsonl --replay
python scripts/run_answer_repair_v9.py --dataset fever --strategy qwen_direct --all --c1 inputs/fever_smoke5_c1.jsonl --out results/fever_smoke5_qwen_direct.jsonl --check-only
python scripts/run_answer_repair_v9.py --dataset fever --strategy qwen_direct --all --c1 inputs/fever_smoke5_c1.jsonl --out results/fever_smoke5_qwen_direct.jsonl
python scripts/run_answer_repair_v9.py --dataset fever --strategy qwen_direct --all --c1 inputs/fever_smoke5_c1.jsonl --out results/fever_smoke5_qwen_direct.jsonl --replay
python scripts/run_answer_repair_v9.py --dataset fever --strategy evidence_id --all --c1 inputs/fever_smoke5_c1.jsonl --out results/fever_smoke5_evidence_id.jsonl --check-only
python scripts/run_answer_repair_v9.py --dataset fever --strategy evidence_id --all --c1 inputs/fever_smoke5_c1.jsonl --out results/fever_smoke5_evidence_id.jsonl
python scripts/run_answer_repair_v9.py --dataset fever --strategy evidence_id --all --c1 inputs/fever_smoke5_c1.jsonl --out results/fever_smoke5_evidence_id.jsonl --replay
python scripts/run_answer_repair_v9.py --dataset fever --strategy factored_evidence_id --all --c1 inputs/fever_smoke5_c1.jsonl --out results/fever_smoke5_factored_evidence_id.jsonl --check-only
python scripts/run_answer_repair_v9.py --dataset fever --strategy factored_evidence_id --all --c1 inputs/fever_smoke5_c1.jsonl --out results/fever_smoke5_factored_evidence_id.jsonl
python scripts/run_answer_repair_v9.py --dataset fever --strategy factored_evidence_id --all --c1 inputs/fever_smoke5_c1.jsonl --out results/fever_smoke5_factored_evidence_id.jsonl --replay
