"""Per-question latency of the product (quality_adaptive_v1) on confirm questions.

Online path: pipeline.run(query) one question at a time (no batching), after warm-up questions that are not timed.
Stage timers wrap the live objects: C1 (BGE Top-5 + Qwen generation), diagnosis (classifier + runtime features),
Controller (P3 / BM25), answer selection. Questions only; no gold on this host.
"""
import argparse, json, sys, time
from pathlib import Path

CODE = Path('/root/autodl-tmp/e648/l2/code_adaptive')
sys.path.insert(0, str(CODE))
import torch
from src.pipeline.current import load_current_pipeline
from src.generation.qwen import apply_qwen_chat_template

p = argparse.ArgumentParser()
p.add_argument('--queries', type=Path, required=True)
p.add_argument('--ids', type=Path, required=True, help='{"warmup": [...], "timed": [...]}')
p.add_argument('--output', type=Path, required=True)
args = p.parse_args()
query = {r['sample_id']: r['query'] for r in map(json.loads, args.queries.read_text().splitlines())}
ids = json.loads(args.ids.read_text())
t0 = time.perf_counter()
pipeline, environment = load_current_pipeline(
    root=CODE, nq_resources=CODE / 'configs/controller/nq_train_resources_v1.json', data_role='validation',
    attach_reference_rag=True, allow_sealed_test=False, registration='configs/controller/quality_adaptive_v1.json')
load_seconds = time.perf_counter() - t0

T = {}
def timed(key, fn):
    def wrap(*a, **k):
        torch.cuda.synchronize(); start = time.perf_counter()
        try:
            return fn(*a, **k)
        finally:
            torch.cuda.synchronize(); T[key] = T.get(key, 0.0) + time.perf_counter() - start
    return wrap

rr, host = pipeline.host.reference_rag, pipeline.host
gen0 = rr._generate
def c1_generate(tokenizer, model, prompt, max_new_tokens):
    T['c1_input_tokens'] = len(tokenizer(apply_qwen_chat_template(tokenizer, prompt))['input_ids'])
    out = gen0(tokenizer, model, prompt, max_new_tokens)
    T['c1_output_tokens'] = len(tokenizer(out[0])['input_ids'])
    return out
rr._generate = timed('c1_generate_s', c1_generate)
rr.run = timed('c1_s', rr.run)
host.classifier.diagnose = timed('diagnosis_classifier_s', host.classifier.diagnose)
pipeline.features.features_for_batch = timed('diagnosis_features_s', pipeline.features.features_for_batch)
host.run_from_prepared = timed('controller_s', host.run_from_prepared)
assert pipeline.answer_selection is not None
pipeline.answer_selection = timed('answer_selection_s', pipeline.answer_selection)

for sid in ids['warmup']:
    pipeline.run(query[sid], sample_id=sid)
with args.output.open('x') as out:
    for i, sid in enumerate(ids['timed']):
        T.clear()
        torch.cuda.synchronize(); start = time.perf_counter()
        d = pipeline.run(query[sid], sample_id=sid).to_dict()
        torch.cuda.synchronize(); total = time.perf_counter() - start
        sel = d['metadata'].get('answer_selection') or {}
        out.write(json.dumps({'sample_id': sid, 'total_s': total, **T, 'c1': d['initial_answer'], 'final_answer': d['final_answer'],
                              'action': d['controller_decision']['action'], 'controller_answer': d['enhancement_result']['final_answer'],
                              'enhancement_cost': d['metadata']['enhancement_cost'], 'selection_stage': sel.get('stage'),
                              'selection_cost': sel.get('cost')}, default=str) + '\n')
        out.flush()
        if (i + 1) % 25 == 0:
            print(json.dumps({'done': i + 1, 'of': len(ids['timed'])}), flush=True)
gpu = torch.cuda.get_device_name(0)
args.output.with_suffix('.manifest.json').write_text(json.dumps(
    {'state': 'completed', 'n': len(ids['timed']), 'warmup': len(ids['warmup']), 'load_seconds': load_seconds, 'gpu': gpu,
     'torch': torch.__version__, 'registration': 'configs/controller/quality_adaptive_v1.json', 'path': 'pipeline.run, one question at a time'},
    indent=2) + '\n')
print('EXIT 0', flush=True)
