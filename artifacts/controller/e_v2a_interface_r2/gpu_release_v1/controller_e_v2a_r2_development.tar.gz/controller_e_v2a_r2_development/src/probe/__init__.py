"""Capability probe components."""
