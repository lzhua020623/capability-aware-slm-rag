#!/bin/bash
set -u
cd /root/autodl-tmp/e648/l2/timing
export HF_HOME=/root/autodl-tmp/hf HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_HUB_DISABLE_XET=1
export TOKENIZERS_PARALLELISM=false PYTHONUNBUFFERED=1 OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 CUDA_VISIBLE_DEVICES=0
/root/autodl-tmp/e648/venv/bin/python time_pipeline.py --queries /root/autodl-tmp/e648/round2/inputs/confirm_queries.jsonl \
  --ids ids.json --output latency.jsonl
echo "EXIT $?"
